import React, { useEffect, useState, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Logo from './Logo'

/*
  Professional cinematic intro:
  - Clean gradient with vignette
  - Branded MediSphere logomark + wordmark
  - Soft light sweep and premium reveal
  - Creator credit: Code Crusaders
*/

export default function Intro({ onDone }) {
  const [show, setShow] = useState(true)
  const [phase, setPhase] = useState('intro') // intro -> reveal -> done
  const videoRef = useRef(null)
  const videoUrl = import.meta.env.VITE_INTRO_VIDEO_URL

  const INTRO_MS = 2800

  useEffect(() => {
    if (!videoUrl) {
      const t = setTimeout(() => setPhase('reveal'), INTRO_MS)
      return () => clearTimeout(t)
    }
  }, [videoUrl])

  useEffect(() => {
    if (phase === 'reveal') {
      const t = setTimeout(() => {
        setPhase('done')
        setShow(false)
      }, 900)
      return () => clearTimeout(t)
    }
  }, [phase])

  const handleEnd = () => setPhase('reveal')
  const handleSkip = () => { setPhase('done'); setShow(false) }

  useEffect(() => { if (!show && onDone) onDone() }, [show, onDone])

  const LightSweep = () => (
    <motion.div
      initial={{ x: '-20%' }}
      animate={{ x: '120%' }}
      transition={{ duration: 1.2, ease: 'easeInOut', delay: 0.6 }}
      className="absolute top-1/2 -translate-y-1/2 w-1/3 h-[180px] bg-gradient-to-r from-transparent via-white/10 to-transparent blur-2xl"
      style={{ pointerEvents: 'none' }}
    />
  )

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-slate-950"
        >
          {/* Background video if provided, otherwise premium gradient */}
          {videoUrl ? (
            <div className="absolute inset-0">
              <video
                ref={videoRef}
                src={videoUrl}
                className="w-full h-full object-cover"
                autoPlay
                muted
                playsInline
                onEnded={handleEnd}
              />
              <div className="absolute inset-0 bg-slate-950/40" />
            </div>
          ) : (
            <>
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_30%,rgba(56,189,248,0.08),transparent_45%),radial-gradient(circle_at_80%_70%,rgba(34,197,94,0.06),transparent_40%)]" />
              <div className="absolute inset-0 bg-gradient-to-b from-slate-900/60 via-slate-950 to-slate-950" />
              <div className="absolute inset-0 pointer-events-none" style={{ boxShadow: 'inset 0 0 220px rgba(0,0,0,0.7)' }} />
            </>
          )}

          {/* Center logomark + wordmark */}
          <div className="absolute inset-0 flex items-center justify-center">
            <motion.div
              initial={{ scale: 0.985, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="px-10 py-8 rounded-2xl bg-white/2 backdrop-blur-sm border border-white/10"
            >
              <Logo size={180} showWordmark animated />
              <div className="mt-3 text-center text-slate-300 tracking-wide" style={{ fontSize: '1.125rem' }}>
                Created by <span className="text-cyan-200">Code Crusaders</span>
              </div>
            </motion.div>
          </div>

          {/* Cinematic light sweep */}
          <LightSweep />

          {/* Reveal transition: minimal upward wipe */}
          <AnimatePresence>
            {phase === 'reveal' && (
              <motion.div
                initial={{ y: 0, opacity: 1 }}
                animate={{ y: '-100%', opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.9, ease: 'easeInOut' }}
                className="absolute inset-0 bg-slate-950"
              />
            )}
          </AnimatePresence>

          {/* Skip control */}
          <div className="absolute top-4 right-4">
            <button
              onClick={handleSkip}
              className="px-3 py-2 rounded-lg bg-slate-900/70 text-slate-200 border border-white/10 hover:bg-slate-800 text-sm"
            >
              Skip
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
