import React, { useState, useRef } from 'react'
import { motion } from 'framer-motion'
import { UploadCloud, FileCheck, AlertCircle, Check } from 'lucide-react'

const DRUGS = [
  'CODEINE',
  'WARFARIN',
  'CLOPIDOGREL',
  'SIMVASTATIN',
  'AZATHIOPRINE',
  'FLUOROURACIL',
]

export default function UploadForm({ onAnalyze }) {
  const [file, setFile] = useState(null)
  const [selected, setSelected] = useState([])
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const dropRef = useRef(null)

  const toggleDrug = (drug) => {
    setSelected((prev) => prev.includes(drug) ? prev.filter(d => d !== drug) : [...prev, drug])
  }

  const handleDrop = (e) => {
    e.preventDefault()
    const f = e.dataTransfer.files[0]
    if (f) validateFile(f)
  }
  const validateFile = (f) => {
    setError('')
    if (!f.name.toLowerCase().endsWith('.vcf')) {
      setError('Please upload a .vcf file')
      return
    }
    if (f.size > 5_000_000) {
      setError('File exceeds 5MB limit')
      return
    }
    setFile(f)
  }

  const handleAnalyze = async () => {
    setError('')
    if (!file) { setError('Please select a VCF file'); return }
    if (!selected.length) { setError('Please select at least one drug'); return }
    setLoading(true)
    try {
      const form = new FormData()
      form.append('file', file)
      form.append('drugs', selected.join(','))
      const res = await fetch(`${import.meta.env.VITE_BACKEND_URL || ''}/analyze`, {
        method: 'POST',
        body: form
      })
      if (!res.ok) throw new Error(await res.text())
      const data = await res.json()
      onAnalyze(data)
    } catch (e) {
      setError('Analysis failed. Please check file and inputs.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="bg-white/5 border border-white/10 rounded-2xl p-6 md:p-8">
      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <div
            ref={dropRef}
            onDragOver={(e)=>e.preventDefault()}
            onDrop={handleDrop}
            className="relative rounded-xl border-2 border-dashed border-cyan-400/40 p-6 md:p-8 text-center hover:border-cyan-300/60 transition"
          >
            <UploadCloud className="w-10 h-10 text-cyan-300 mx-auto" />
            <p className="mt-2 text-cyan-50 font-medium">Drag & drop VCF here</p>
            <p className="text-sm text-cyan-200/70">VCF v4.2 • up to 5MB • INFO tags: GENE, STAR, RS</p>
            <div className="mt-4">
              <label className="inline-flex items-center px-4 py-2 rounded-lg bg-cyan-500/20 text-cyan-100 hover:bg-cyan-500/30 cursor-pointer transition">
                <input type="file" accept=".vcf" className="hidden" onChange={(e)=>validateFile(e.target.files[0])} />
                <FileCheck className="w-5 h-5 mr-2" /> Select file
              </label>
            </div>
            {file && <p className="mt-3 text-cyan-200/80">Selected: {file.name}</p>}
          </div>
        </div>
        <div className="space-y-4">
          <label className="block text-cyan-100 text-sm">Select Drugs</label>
          <div className="flex flex-wrap gap-2">
            {DRUGS.map((drug) => {
              const active = selected.includes(drug)
              return (
                <button
                  type="button"
                  key={drug}
                  onClick={() => toggleDrug(drug)}
                  className={`px-3 py-2 rounded-lg border text-sm flex items-center gap-1 transition ${active ? 'bg-cyan-500 text-slate-900 border-cyan-400 hover:bg-cyan-400' : 'bg-slate-800 text-slate-200 border-white/10 hover:bg-slate-700'}`}
                >
                  {active && <Check className="w-4 h-4" />} {drug}
                </button>
              )
            })}
          </div>
          <button onClick={handleAnalyze} className="w-full px-4 py-3 rounded-lg bg-cyan-500 text-slate-900 font-semibold hover:bg-cyan-400 transition">
            {loading ? 'Analyzing...' : 'Analyze'}
          </button>
          {error && (
            <div className="flex items-start gap-2 text-red-300 bg-red-900/20 border border-red-700/40 rounded-lg p-3">
              <AlertCircle className="w-5 h-5 mt-0.5" />
              <p className="text-sm">{error}</p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  )
}
