import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import Logo from './Logo'

let SplineComp = null

function isWebGLAvailable() {
  try {
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl')
    return !!gl
  } catch (e) {
    return false
  }
}

export default function Hero() {
  const [canUseWebGL, setCanUseWebGL] = useState(false)
  const [isSmall, setIsSmall] = useState(false)
  const [reducedMotion, setReducedMotion] = useState(false)

  useEffect(() => {
    const width = window.innerWidth
    setIsSmall(width < 1024) // limit 3D to larger screens only

    const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    setReducedMotion(mq.matches)
    const onChange = (e) => setReducedMotion(e.matches)
    if (mq.addEventListener) mq.addEventListener('change', onChange)
    else if (mq.addListener) mq.addListener(onChange)

    const ok = isWebGLAvailable()
    if (ok && !isSmall && !reducedMotion && !SplineComp) {
      import('@splinetool/react-spline')
        .then(mod => {
          SplineComp = mod.default
          setCanUseWebGL(true)
        })
        .catch(() => setCanUseWebGL(false))
    } else {
      setCanUseWebGL(false)
    }

    return () => {
      if (mq.removeEventListener) mq.removeEventListener('change', onChange)
      else if (mq.removeListener) mq.removeListener(onChange)
    }
  }, [])

  return (
    <div className="relative w-full h-[520px] overflow-hidden bg-blue-900">
      {/* Always-visible polished background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900">
        <div className="absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_20%_30%,rgba(255,255,255,0.15),transparent_40%),radial-gradient(circle_at_80%_70%,rgba(255,255,255,0.12),transparent_35%)]" />
        <div className="absolute right-[-80px] top-[-40px] w-[420px] h-[420px] rounded-full bg-cyan-400/20 blur-3xl" />
        <div className="absolute left-[-120px] bottom-[-120px] w-[520px] h-[520px] rounded-full bg-indigo-400/20 blur-3xl" />
      </div>

      {/* 3D DNA cover only on capable large screens to avoid lag */}
      {canUseWebGL && SplineComp ? (
        <div className="absolute inset-0" aria-hidden>
          <SplineComp scene="https://prod.spline.design/5EwoDiC2tChvmy4K/scene.splinecode" />
        </div>
      ) : null}

      {/* Readability veil */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-900/70 via-slate-900/40 to-transparent" />

      {/* Foreground content */}
      <div className="relative max-w-6xl mx-auto px-6 md:px-10 h-full flex items-center">
        <div className="text-white">
          <motion.div initial={{opacity:0, y:reducedMotion ? 0 : 16}} animate={{opacity:1, y:0}} transition={{duration:reducedMotion ? 0 : 0.5}} className="mb-4 inline-flex items-center gap-4">
            <Logo size={96} animated={!reducedMotion} />
            <span className="text-sm uppercase tracking-widest text-cyan-200/80">MediSphere</span>
          </motion.div>
          <motion.h1 initial={{opacity:0, y:reducedMotion ? 0 : 8}} animate={{opacity:1, y:0}} transition={{delay:0.04, duration:reducedMotion ? 0 : 0.5}} className="text-3xl md:text-5xl font-bold tracking-tight drop-shadow-md">
            AI Pharmacogenomic Risk Prediction
          </motion.h1>
          <motion.p initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.12, duration:reducedMotion ? 0 : 0.5}} className="mt-3 md:mt-4 text-cyan-100/90 max-w-2xl">
            Upload authentic VCF files, analyze key gene variants, and receive CPIC-aligned dosing guidance with clear, LLM-generated explanations.
          </motion.p>
        </div>
      </div>
    </div>
  )
}
