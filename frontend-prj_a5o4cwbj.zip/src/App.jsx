import React, { useState } from 'react'
import { motion } from 'framer-motion'
import Intro from './components/Intro'
import Hero from './components/Hero'
import UploadForm from './components/UploadForm'
import Results from './components/Results'
import MetricsCards from './components/MetricsCards'
import Chatbot from './components/Chatbot'

function App() {
  const [result, setResult] = useState(null)
  const [introDone, setIntroDone] = useState(false)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      {!introDone && <Intro onDone={()=>setIntroDone(true)} />}
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6 }}>
        <Hero />
        <div className="max-w-6xl mx-auto px-6 md:px-10 py-8 md:py-12">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
              <UploadForm onAnalyze={(data)=>setResult(data)} />
              {result && (
                <div className="mt-6 space-y-6">
                  <MetricsCards summary={result.summary} />
                  <Results data={result} />
                </div>
              )}
            </div>
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }} className="space-y-6">
              <div className="rounded-2xl bg-white/5 border border-white/10 p-6">
                <h3 className="text-lg font-semibold">Supported Genes & Drugs</h3>
                <ul className="mt-3 text-sm text-slate-200 space-y-1">
                  <li>CYP2D6 — Codeine</li>
                  <li>CYP2C19 — Clopidogrel</li>
                  <li>CYP2C9 — Warfarin</li>
                  <li>SLCO1B1 — Simvastatin</li>
                  <li>TPMT — Azathioprine</li>
                  <li>DPYD — Fluorouracil</li>
                </ul>
                <p className="mt-3 text-xs text-slate-400">VCF INFO tags required: GENE, STAR, RS</p>
              </div>
              <Chatbot patientId={result?.summary?.patient_id} />
            </motion.div>
          </div>
        </div>
        <footer className="border-t border-white/10 py-6 text-center">
          <div className="space-y-1">
            <div className="text-slate-400 text-sm">MediSphere • AI Pharmacogenomics • Educational use only</div>
            <div className="text-slate-200 font-medium" style={{ fontSize: '1.3125rem' }}>Created by Code Crusaders</div>
          </div>
        </footer>
      </motion.div>
    </div>
  )
}

export default App
